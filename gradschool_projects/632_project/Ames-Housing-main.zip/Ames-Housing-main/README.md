# Ames-Housing
Comparing Boruta Random Forest and Multiple Linear Regression
